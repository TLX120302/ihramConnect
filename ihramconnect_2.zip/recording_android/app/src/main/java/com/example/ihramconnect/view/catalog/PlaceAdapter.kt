package com.example.ihramconnect.view.catalog

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ihramconnect.R
import com.example.ihramconnect.data.Place

class PlaceAdapter(private val places: List<Place>) : RecyclerView.Adapter<PlaceAdapter.PlaceViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlaceViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_place, parent, false)
        return PlaceViewHolder(view)
    }

    override fun onBindViewHolder(holder: PlaceViewHolder, position: Int) {
        val place = places[position]
        holder.bind(place)
    }

    override fun getItemCount(): Int {
        return places.size
    }

    inner class PlaceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val placeNameTextView: TextView = itemView.findViewById(R.id.place_name)
        private val placeAddressTextView: TextView = itemView.findViewById(R.id.place_address)
        private val placeRatingTextView: TextView = itemView.findViewById(R.id.place_rating)

        fun bind(place: Place) {
            placeNameTextView.text = place.place
            placeAddressTextView.text = place.alamat
            placeRatingTextView.text = "Rating: ${place.rating}"
        }
    }
}
